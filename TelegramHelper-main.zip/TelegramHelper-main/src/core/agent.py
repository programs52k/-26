"""LLM-роутер интентов: свободный текст владельца → структурированное действие.

Подтверждение действий, видимых другим (отправка), решается на уровне хэндлера.
"""
from __future__ import annotations

import json
import logging
from typing import Any

from src.llm.base import ChatMessage, LLMProvider


logger = logging.getLogger(__name__)


AGENT_SYSTEM = """\
Ты роутер интентов для AI-ассистента в Telegram. Получаешь свободную фразу владельца и
возвращаешь СТРОГИЙ JSON-объект (без markdown-обёртки, без префиксов), описывающий
действие, которое нужно выполнить.

Доступные действия (поле "intent"):

1) "send_message"  — отправить сообщение конкретному контакту от имени владельца.
   Параметры:
     "recipient": "имя/ник/описание контакта",
     "text":      "финальный текст сообщения, в первом лице, без префиксов «передай»/«скажи»".
   Используй когда фраза вида «напиши/скажи/передай/отправь Х что Y».

2) "summarize_chat" — сделать саммари переписки с контактом.
   Параметры: "contact": "имя".

3) "tasks_for_chat" — извлечь задачи/обещания из переписки с контактом.
   Параметры: "contact": "имя".

4) "draft_reply"   — подготовить черновик ответа в чате с контактом.
   Параметры: "contact": "имя", "instruction": "опц. инструкция или null".

5) "catchup"       — «где мы остановились» + черновик ответа в чате с контактом.
   Параметры: "contact": "имя".

6) "search"        — поиск по моим сообщениям (по смыслу, не точному совпадению).
   Параметры: "query": "формулировка для поиска".

7) "news_digest"   — собрать новостной дайджест по теме из моих подписанных каналов.
   Параметры: "topic": "тема", "hours": int (окно часов; 24 если не указано).

8) "list_todos"    — показать мои открытые обещания.
   Параметров нет.

9) "set_setting"   — изменить одну настройку.
   Параметры: "key": <одно из перечисленного>, "value": <значение>.
   Допустимые ключи и форматы значений:
     - "auto_reply_enabled"        : true/false
     - "auto_reply_mode"           : "static" | "smart"
     - "auto_reply_text"           : строка (сам текст автоответа)
     - "auto_reply_cooldown_min"   : int (минуты)
     - "digest_enabled"            : true/false
     - "digest_time"               : "HH:MM" (в TZ владельца)
     - "news_enabled"              : true/false
     - "news_digest_time"          : "HH:MM"
     - "news_window_hours"         : int часов
     - "reminders_enabled"         : true/false
     - "reminder_lead_hours"       : int
     - "reminder_overdue_enabled"  : true/false
     - "ignore_archived"           : true/false
     - "use_heavy_model"           : true/false
     - "llm_provider"              : "openai" | "gemini"
     - "transcription_mode"        : "local" | "api" | "hybrid"
     - "timezone"                  : IANA (Europe/Moscow и т.п.)
   Используй для фраз: «включи Х», «выключи Х», «дайджест в 7 утра», «часовой пояс Лондон»,
   «новости в 9», «не показывай архив», «переключись на gemini», «текст автоответа: …» и т.п.
   Если просят «новости в 9», ставь news_digest_time = "09:00" И ОТДЕЛЬНО news_enabled=true
   ВТОРЫМ интентом (см. ниже формат "multi"). Аналогично для дайджеста.

9.1) "find_in_chats" — найти чат по теме (когда конкретный контакт НЕ назван) и
   выполнить действие.
   Параметры:
     "query":  "ключевые слова для глобального поиска по моим перепискам в Telegram
                (на русском или английском, как в исходном сообщении)",
     "action": "catchup" | "summary" | "tasks" | "draft"  (по умолчанию "catchup").
   Используй когда фраза вида «в одном из чатов», «где-то я обсуждал», «у меня где-то
   был разговор про X», «на чём мы остановились с тем магазином мебели». Не выдумывай
   контакт — пусть пользователь выберет из найденных кнопками.

10) "add_news_topic" — добавить тему утренних авто-новостей.
    Параметры: "topic": "тема", "hours": int (опционально, default 24).
    Используй для «добавь тему Х», «следить за Х», «утром присылай по теме Х».

11) "remove_news_topic" — удалить тему утренних авто-новостей.
    Параметры: "topic": "подстрока для поиска темы".

11.1) "add_reminder" — поставить персональное напоминание (Commitment direction="mine").
    Параметры:
      "text": "что напомнить (одна фраза)",
      "when": "ISO-8601 datetime в UTC (например 2026-05-10T15:00:00Z) или null если нет даты",
      "peer_query": null | "имя контакта, если контекст связан с конкретным чатом".
    Используй для «напомни мне завтра в 18:00 позвонить маме», «поставь напоминание
    через час сделать X», «не забыть Y».

11.2) "remove_reminder" — снять напоминание/обещание.
    Параметры:
      "query": "подстрока в тексте напоминания или имени контакта".
    Используй для «убери напоминание про X», «выключи напоминание Y».

11.3) "add_reminders_from_chat" — извлечь обещания из чата с контактом и поставить как
    напоминания.
    Параметры: "contact": "имя контакта".
    Используй для «поставь напоминания из чата с Артёмом», «выкуси задачи из переписки
    с боссом и поставь напоминания».

12) "chat"         — просто ответить владельцу текстом (общий вопрос/болтовня/совет/
    объяснение, не требующее действий с Telegram).
    Параметры: "reply": "готовый ответ в свободной форме (можно несколько абзацев,
    HTML aiogram-разметка допустима: <b>, <i>, <code>)".

13) "unknown"      — не получилось понять. Параметров нет.

ОСОБЫЙ СЛУЧАЙ — несколько действий за раз.
Если фраза требует НЕСКОЛЬКО действий ("включи новости и дайджест в 7 утра",
"добавь тему AI и пришли дайджест прямо сейчас"), верни:
  {"intent": "multi", "actions": [<intent-объект>, <intent-объект>, ...]}
где каждый элемент — обычный intent-объект (включая "set_setting" и пр.).

Возвращай ТОЛЬКО валидный JSON-объект. Никаких пояснений снаружи. Не выдумывай поля,
которых нет. Если для действия не хватает данных — выбери "chat" и в "reply" попроси
уточнение.
"""


def _strip_fence(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
        text = text.strip()
    return text


def _safe_parse(raw: str) -> dict[str, Any]:
    raw = _strip_fence(raw)
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, dict) and isinstance(parsed.get("intent"), str):
            return parsed
    except Exception:
        logger.warning("agent: bad JSON: %r", raw[:200])
    return {"intent": "unknown"}


async def route_intent(
    provider: LLMProvider,
    user_text: str,
    *,
    heavy: bool = False,
    now_local: str | None = None,
    tz_name: str | None = None,
    history_block: str | None = None,
) -> dict[str, Any]:
    """now_local + tz_name инжектятся в системный промпт, чтобы LLM мог парсить
    относительные даты («завтра в 18:00») в корректный UTC ISO.
    history_block — краткосрочная память диалога владельца с ботом, чтобы понимать
    отсылки вроде «ему», «в том же чате»."""
    system = AGENT_SYSTEM
    if now_local and tz_name:
        system = (
            f"Текущее локальное время владельца: {now_local} ({tz_name}).\n"
            f"Когда нужно превратить относительную дату («завтра», «через час», «в пятницу 18:00») "
            f"в ISO-8601, считай в этом TZ и потом конвертируй в UTC.\n\n"
            + system
        )
    if history_block:
        system = system + "\n\n" + history_block
    raw = await provider.chat(
        [
            ChatMessage(role="system", content=system),
            ChatMessage(role="user", content=user_text),
        ],
        heavy=heavy,
    )
    return _safe_parse(raw)
